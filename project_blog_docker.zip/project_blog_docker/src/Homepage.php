<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
</head>
<body>
<h1>WELCOME !<h1>
<h4>You can :</h4>
<button type="submit" name="Sign in">SIGN IN</button>
<button type="submit" name="Sign in">CREATE A POST</button>
</body>
</html>